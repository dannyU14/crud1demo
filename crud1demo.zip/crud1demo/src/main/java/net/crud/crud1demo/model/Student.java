package net.crud.crud1demo.model;

import java.sql.Date;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="Students")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long uniqueId;

    private String name;
    private String surname;
    private String patronymic;
    private Date birthDate;
    private String groupNum;


}
