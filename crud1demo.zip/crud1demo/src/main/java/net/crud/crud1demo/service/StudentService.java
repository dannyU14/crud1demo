package net.crud.crud1demo.service;

import net.crud.crud1demo.model.Student;
import net.crud.crud1demo.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository studentRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository){
        this.studentRepository = studentRepository;
    }

    public Student findById(Long uniqueId){
        return studentRepository.getOne(uniqueId);
    }
    public List<Student> findAll(){
        return studentRepository.findAll();
    }
    public Student saveStudent(Student student){
        return studentRepository.save(student);
    }
    public void deleteById(Long uniqueId){
        studentRepository.deleteById(uniqueId);
    }




}
