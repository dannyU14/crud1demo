package net.crud.crud1demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Crud1demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
